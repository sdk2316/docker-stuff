Docker Mock Server
=================

Requirements
============

- docker-ce
- docker-compose

How to create the service
========================

Well, there's not much to see here. Just type dcker-compose up -d.

Checking the service
====================

After you are done, hit `http://localhost:8888` and see the magic.

